/*
 * @Authr: zhangshuai
 * @Date: 2023-01-03 11:25:52
 * @LastEditrs: zhangshuai
 * @LastEditTime: 2023-01-05 16:18:35
 * @Descriptin: 
 */
import React from 'react';
import ReactDOM from 'react-dom/client';
import './index.css';
import App from './App';

const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(
  <React.StrictMode>
    <App />
  </React.StrictMode>
);
