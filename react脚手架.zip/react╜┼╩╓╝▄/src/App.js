/*
 * @Authr: zhangshuai
 * @Date: 2023-01-03 11:25:52
 * @LastEditrs: zhangshuai
 * @LastEditTime: 2023-01-06 10:36:44
 * @Descriptin: 
 * lesson1 组件的引入以及 css样式的模块化写法
 * lesson2 组件的组合使用（TodoList案例）
 * lesson3 发送请求以及代理配置
 */
import React from "react";
import "./App.css"

// lesson1
// import Imgcom from "./component/lesson1/Imgcom";
// import Hello from "./component/lesson1/hello";

// lesson2
// import Header from './component/lesson2/header'
// import List from './component/lesson2/list'
// import Bottom from './component/lesson2/bottom'

// lesson3
import Login from './component/lesson3/request' 
import List from "./component/lesson3/List";

// 创建并暴露App组件
export default class App extends React.Component{
  state={
    listDate:[{
        id:'1',
        value:'吃饭',
        isChecked:false,
    },{
        id:'2',
        value:'睡觉',
        isChecked:false,
    },{
        id:'3',
        value:'打豆豆',
        isChecked:true,
    }]
  }
  addDate=(newDate)=>{
    this.setState({listDate:[newDate,...this.state.listDate]})
  }
  deleteDate=(index)=>{
    let {listDate} = this.state
    listDate.splice(index,1)
    this.setState({listDate})
  }
  changeItem=(index,type)=>{
    let {listDate} = this.state
    listDate[index].isChecked = type
    this.setState({listDate})
  }
  changeAll=(type)=>{
    let {listDate} = this.state
    let newList = listDate.map(item => {
      return {...item,isChecked:type}
    });
    this.setState({listDate:newList})
    console.log(this.state)
  }
  clearSelect=()=>{
    let {listDate} = this.state
    let newArr = listDate.filter(item=>{
      return !item.isChecked
    })
    this.setState({listDate:newArr})
  }
  render(){
    // let {listDate} = this.state
    console.log('render')
    return (
      <div className="App">
          {/* lesson1 */}
          {/* <Imgcom/>
          <Hello/> */}

          {/* lesson2 */}
          {/* <Header add={this.addDate}/>
          <List listDate={listDate} deleteDate={this.deleteDate} changeItem={this.changeItem}/>
          <Bottom listDate={listDate} changeAll={this.changeAll} clearSelect={this.clearSelect}/> */}
      
          {/* lesson3 */}
          <Login/>
          <List/>
      </div>
    )
  }
}

