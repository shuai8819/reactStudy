/*
 * @Authr: zhangshuai
 * @Date: 2023-01-04 08:13:30
 * @LastEditrs: zhangshuai
 * @LastEditTime: 2023-01-04 13:34:53
 * @Descriptin: 
 */
import React, { Component } from 'react';
import './index.scss'

class Header extends Component {

    inputEnter=(e)=>{
        if(e.keyCode !==13) return
        let value = e.target.value.trim()
        if(!value){
            alert('输入的内容不能为空')
        }else{
            let obj={
                id: new Date().getTime(),
                value:value,
                isChecked:false,
            }
            this.props.add(obj)
            e.target.value=''
        }

    }
    render() {
        return (
            <div className='inputPart'>
                <input onKeyUp={this.inputEnter} className='valueInput' type="text" />
            </div>
        );
    }
}

export default Header;