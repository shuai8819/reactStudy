/*
 * @Authr: zhangshuai
 * @Date: 2023-01-04 08:18:16
 * @LastEditrs: zhangshuai
 * @LastEditTime: 2023-01-04 15:22:36
 * @Descriptin: 
 */
import React, { Component } from 'react';
import "./index.scss"

class Bottom extends Component {
    setlength=(data)=>{
        let complete =0
        data.forEach(item => {
            if(item.isChecked) complete++
        })
        this.setState({
            all:data.length,
            complete
        })
    }
    allChange=(e)=>{
        this.props.changeAll(e.target.checked)
    }
    clearSelect=()=>{
        this.props.clearSelect()
    }
    render() {
        let {listDate} = this.props
        let complete =0
        let all = listDate.length
        listDate.forEach(item => {
            if(item.isChecked) complete++
        })
        return (
            <div className='bottomPart'>
                <span>{Number(complete)===Number(all)?true:false}</span>
                <input type="checkbox" checked={Number(complete)===Number(all)?true:false} onChange={this.allChange}/>
                <span>已完成{complete}/全部{all}</span>
                <button className='deleteBtn' onClick={this.clearSelect}>清除已完成任务</button>
            </div>
        );
    }
}

export default Bottom;