/*
 * @Authr: zhangshuai
 * @Date: 2023-01-04 08:17:55
 * @LastEditrs: zhangshuai
 * @LastEditTime: 2023-01-04 15:24:41
 * @Descriptin: 
 */
import React, { Component } from 'react';
import "./index.scss"

class List extends Component {
    delete=(index)=>{
        this.props.deleteDate(index)
    }
    changeSelect(index,e){
        this.props.changeItem(index,e.target.checked)
    }
    render() {
        let {listDate} = this.props
        return (
            <div className='listPart'>
                {
                    listDate.map((item,index)=>{
                        console.log(item.isChecked)
                        return(
                            <div key={item.id} className='item'>
                                <input onChange={this.changeSelect.bind(this,index)} type="checkbox" checked={item.isChecked} name="item"/>
                                <span>{item.value}</span>
                                <button onClick={this.delete.bind(this,index)} className='deleteBtn'>删除</button>
                            </div>
                        )
                    })
                }
            </div>
        );
    }
}

export default List;