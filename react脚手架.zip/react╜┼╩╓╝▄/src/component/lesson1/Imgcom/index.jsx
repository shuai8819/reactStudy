/*
 * @Authr: zhangshuai
 * @Date: 2023-01-03 14:03:13
 * @LastEditrs: zhangshuai
 * @LastEditTime: 2023-01-03 14:52:02
 * @Descriptin: 
 */
import React from "react";
import logo from "./img/logo.svg";
// CSS模块化引入
import Imgcss from "./index.module.css";

export default class Imgcom extends React.Component{
    render(){
        return(
            <img className={Imgcss.logo} src={logo} alt="logo"/>
        )
    }
}