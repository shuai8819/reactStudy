/*
 * @Authr: zhangshuai
 * @Date: 2023-01-03 14:05:44
 * @LastEditrs: zhangshuai
 * @LastEditTime: 2023-01-03 15:14:39
 * @Descriptin: 
 */
import React from "react";
import "./index.css"

export default class Hello extends React.Component{
    render(){
        return(
            <p className="tips">hello react</p>
        )
    }
}

