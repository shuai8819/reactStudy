/*
 * @Authr: zhangshuai
 * @Date: 2023-01-05 08:58:48
 * @LastEditrs: zhangshuai
 * @LastEditTime: 2023-01-06 10:49:04
 * @Descriptin: 
 */
import React, { Component } from 'react'
import axios from 'axios'
import md5 from 'blueimp-md5'
import PubSub from 'pubsub-js'

export default class Login extends Component {
    state={
        userName:'',
        passWord:''
    }
    changeVal=(type,e)=>{
        console.log(type,e)
        let val = e.target.value
        if(type ==='n'){
          this.setState({
            userName:val
          })
        }else{
          this.setState({
            passWord:val
          })
        }
    }
    submitForm=()=>{
        let {userName,passWord}=this.state
        axios({
            method: 'get',
            url: '/api1/loginDashboard',
            params:{
              username: userName,
              password: md5(passWord),
              language: 1,
              dashboard:7
            }
          }).then(function(res){
            alert('请求成功')
            console.log(res)
          })
    }
    getList=()=>{
        axios.get('/api2/plc/plcTagConfig/list')
        .then((res)=>{
           console.log('发布')
           // 发布消息给list
           PubSub.publish('listData',res.data)
           
        })
    }
  render() {
    return (
      <div>
            <div className='formItem'>
                <label htmlFor="user">用户名</label> <input onBlur={this.changeVal.bind(this,'n')} name='user' type="text" />
            </div>
            <div>
                <label htmlFor="passWord">密码</label> <input onBlur={this.changeVal.bind(this,'p')} name='passWord' type="passWord" />
            </div>
            <button className='submit' onClick={this.submitForm}>提交</button>

            <button onClick={this.getList}>获取list数据</button>
      </div>
    )
  }
}
