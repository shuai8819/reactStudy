/*
 * @Authr: zhangshuai
 * @Date: 2023-01-06 10:27:59
 * @LastEditrs: zhangshuai
 * @LastEditTime: 2023-01-06 11:04:55
 * @Descriptin: 
 */
import React, { Component } from 'react'
import PubSub from 'pubsub-js'


export default class List extends Component {
    state=({
        listData:[]
    })

    componentDidMount(){
        this.token = PubSub.subscribe('listData',(_,res)=>{
            console.log('接收')
            console.log(res)
            this.setState({
                listData:res
            })
        })
    }
    componentWillUnmount(){
        PubSub.unsubscribe(this.token)
    }
  render() {
    let {listData} = this.state
    return (
      <div>
          {
            listData.map((item)=>{
                return <p key={item.id}>{item.tagName}</p>
            })
          }
      </div>
    )
  }
}
