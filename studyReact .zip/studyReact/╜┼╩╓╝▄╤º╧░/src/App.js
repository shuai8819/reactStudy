/*
 * @Authr: zhangshuai
 * @Date: 2023-01-03 11:25:52
 * @LastEditrs: zhangshuai
 * @LastEditTime: 2023-01-03 15:30:11
 * @Descriptin: 
 * lesson1 组件的引入以及 css样式的模块化写法
 * lesson2 组件的组合使用（案例）
 */
import React from "react";
import Imgcom from "./component/lesson1/Imgcom";
import Hello from "./component/lesson1/hello";

// 创建并暴露App组件
export default class App extends React.Component{
  render(){
    return (
      <div>
          <Imgcom/>
          <Hello/>
      </div>
    )
  }
}

